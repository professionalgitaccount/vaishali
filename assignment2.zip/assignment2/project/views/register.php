<?php
session_start();
//print_r($_SESSION);
if(isset($_SESSION['project_name'])){
	header("location:index.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="../assets/css/prettyPhoto.css" rel="stylesheet">
    <link href="../assets/css/price-range.css" rel="stylesheet">
    <link href="../assets/css/animate.css" rel="stylesheet">
	<link href="../assets/css/main.css" rel="stylesheet">
	<link href="../assets/css/responsive.css" rel="stylesheet">
    
	
</head>
<body>


<section id="form"><!--form-->
		<div class="container">
			<div class="row">
				<div class="col-sm-4 col-sm-offset-1">
					<div class="login-form"><!--login form-->
						<h2>Login to your account</h2>
							<form id="login_form">
							<input type="text" name="useremail" placeholder="ENTER EMAIL ID" />
							<input type="password" name="userpassword" placeholder="ENTER PASSWORD" />
							<button type="button" class="btn btn-default btn-login">Login</button>
							</form>
		<div class="msg_login"></div>
		</div><!--/login form-->
		</div>
				<div class="col-sm-1">
					<h2 class="or">OR</h2>
				</div>
				<div class="col-sm-4">
					<div class="signup-form"><!--sign up form-->
						<h2>New User Signup!</h2>
	<form id="register_form">
	<input type="text" name="username" placeholder="ENTER NAME" />
	<input type="text" name="user_date_of_birth" placeholder="ENTER DATE OF BIRTH" />
	<input type="text" name="useremail" placeholder="ENTER EMAILID" />
	<input type="password" name="userpassword" placeholder="ENTER PASSWORD" />
	
	<button type="button" class="btn btn-default btn-register">Register</button>
	</form>
	<div class="msg_register"></div>
					</div><!--/sign up form-->
				</div>
			</div>
		</div>
	</section><!--/form-->
	</body>
	<script src="../assets/js/assignment2.js"></script>
</html>


