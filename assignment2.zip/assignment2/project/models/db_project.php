<?php
   require_once 'db_helper.php';
   final class db_project extends db_helper{
   	function user_insert($name,$mobile,$email,$password){
           return parent::insert(
             "users",
             "us_name,us_birth,us_email,us_password",
             "'$name','$birth','$email','$password'"
           );
         }
         function get_user_data($email){
          //echo $email;
          return db_helper::select(
            "*","users","us_email='$email'"
          );
         }
         function get_password_userwise($email){
          //echo $email;
          return db_helper::select(
            "us_password","users","us_email='$email'"
          );
         }



   }

   $obj = new db_project();

?>