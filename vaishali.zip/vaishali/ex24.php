<?php
$product_arr =array(
0=>array("product1",200,"product1.png"),
1=>array("product2",300,"product2.jpg"),
2=>array("product3",400,"product3.jpeg"),
3=>array("product4",500,"product4.jpeg"),
);





?>