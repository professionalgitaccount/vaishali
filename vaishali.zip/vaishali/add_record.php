<link rel="stylesheet" type="text/css" href="bootstrap.min.css">
<div class="container">
	<form method="post" action="add_record_action.php">
		<label>Enter Name</label>
		<input type="text" name="username" placeholder="Enter name"
		class="form-control">
		<label>Enter Salary</label>
		<input type="text" name="usersalary" placeholder="Enter salary"
		class="form-control">
		<input type="submit" class="btn">
	</form>
	
</div>