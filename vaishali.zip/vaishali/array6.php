<?php
$y=10;
if(isset($y)){
	echo $y;
}
else{
	echo "No Exist";
}






?>
