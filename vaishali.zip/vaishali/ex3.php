<?php
$x1=20;
$x2=50;
echo $x1,$x2;
//print $x1,$x2;
//print does not provide output for $x1,$x2
//this is only used in echo