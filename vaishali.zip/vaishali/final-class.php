<?php
abstract class tv{

}
final class sonytv extends tv{

}
//class xyztv extends sonytv{
	
//}
$remote=new sonytv();
print_r($remote);$this->username=$newuser;




?>