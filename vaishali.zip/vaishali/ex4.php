<?php
//comment example
#comment example
/*
error type:notice
*/
$x1=90;
echo $x1;
echo $x1;
//types of error in php:
//syntax
//notice(when the variables are not defined properly it generates notice error)