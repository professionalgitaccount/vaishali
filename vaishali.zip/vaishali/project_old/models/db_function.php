<?php
function send_msg(){
	
}

?>