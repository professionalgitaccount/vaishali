<?php
//7 global arrays
print_r($_GET);
echo "<br>";
print_r($_REQUEST);


foreach($_REQUEST as $val){
	echo $val."";
}








?>