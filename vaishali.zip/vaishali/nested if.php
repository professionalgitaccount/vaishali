<?php
$data=150;
if($data<10){
	echo "single digit";
}
else if($data<100){
	echo "Two digit no";
}
else{
	echo "Multi Digit NO";
}
?>