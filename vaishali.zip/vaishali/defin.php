<?php
define('USER','Akshay',true);
if(defined('user')){
	echo USER;
}
else{
	echo "Not Exist";
}









?>