<?php
$data = array(
"name"=>"Ajay",
"age"=> 20,
"place"=>"Mumbai"
);
echo "<pre>";
print_r($data);
echo "</pre>";
echo $data['place'];
//echo $data['places'];





?>