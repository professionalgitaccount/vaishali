<?php
class tv{
	function showchannel(){
		echo "SONY <br/>";
	}
	//function tv(){
	//echo"CONSTRUCTOR1 <br />";
	// }
	function __construct(){
		echo "CONSTRUCTOR2 <br />";
	}
	function __destruct(){
		echo "DESTRUCTOR <br />";
	}

}
$remote1=new tv();
$remote1->showchannel();
$remote2=new tv();
$remote2->showchannel();//





?>