<?php
//call
calculate(100,200);
//define
function calculate($a,$b,$c){
	echo $a+$b+$c;
}
?>