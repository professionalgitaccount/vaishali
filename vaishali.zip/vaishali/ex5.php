<?php
echo strlen('hello world');
echo  "<br>";//embedding html in php
echo strlen("hello world");
//here strlen is 11 including space between hello and world.
?>
