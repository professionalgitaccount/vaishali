<?php
for($i=1;$i<=5;$i++)
{
	echo $i*$i;
	echo " ";// for space between 1 4 9 16 25($i*$i)
}

$x=1;
while($x<=5){
	echo $x;
	echo " ";
	$x++;
}
?>