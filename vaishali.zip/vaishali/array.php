<?php
$data=[100,200,300];
//echo $data;it will generate notice coz it cannot print complex structures.
print_r($data);
print_r($data[0]);
echo $data[0];//printing data of single element





?>