<?php
$x=10;
$y=$x*$x;
echo "square of $x is $y";
echo "<br>";
echo 'square of $x is $y';//in single quotes everything is consider as a string including $x and $y whereas in double quotes $x and $y is considered as a variable and it prints their value.
?>