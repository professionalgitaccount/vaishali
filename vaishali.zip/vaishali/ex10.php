<?php
$str1 = "Bootstrap is an open source tolkit for developing with HTML,CSS and JS.";
echo($str1);
echo "<br>";
echo substr($str1,5,25);
echo "<br>";
echo substr($str1,-20);
echo "<br>";
echo substr($str1,5,-20);
?>
