<?php
//include("dummy.php");
//include "dummy.php";
//include_once "dummy.php";

//require("dummy.php");
//require "dummy.php";
//require_once "dummy.php";


//echo 1000;
//include"dummy1.php";
//echo 1000;

echo 1000;
require "dummy1.php";
echo 1000;//require stops the execution of whole page if error exist











?>