<a href="ex23.php?name=kurta&amount=1000&color=blue">Mens</a><br>
<a href="ex23.php?name=shirt&amount=2000&color=black">Women</a><br>
<a href="ex23.php?name=shoes&amount=3000&color=green">Kids</a><br>
