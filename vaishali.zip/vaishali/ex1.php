<b>TEST</b>
<style>
	b{background:blue;}
</style>
<?php
echo 100

?>
<script>
	alert()
</script>