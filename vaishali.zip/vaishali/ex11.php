<?php
$x=10;
$y=$x*$x;
//concat,join,dot
//echo 'square of $x is $y';
echo ' square of ' .$x. ' is ' .$y;
?>