<?php
setcookie("product_name","jeans",time()-3600,"/");
setcookie("product_price",10000,time()-3600,"/");


?>