<?php
const DATABASE = "Eshopper";
const DATABASE = "new Database";
echo DATABASE;
//echo database;
//after const everything is case sensitive




?>