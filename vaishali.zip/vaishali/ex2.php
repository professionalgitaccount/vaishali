<?php
$x1=100;
$x2=120;
echo $x1 + $x2;
print $x1 +$x2;
?>

