<?php
echo strtolower("Hello World");
echo"<br>";
echo strtoupper("hello world");
echo"<br>";
echo ucwords("hello world");
echo strtolawer("hello world");

echo ucwords("helo world");
?>
