$(document).ready(function(){
	$(".btn-update").click(function(){

		record =$("#update_form").serialize();
		//console.log(record);
		$.post("../controllers/password-action.php",record).success(function(res){
			$(".msg_update").html(res);
		})
	})

	$(".btn-brand").click(function(){

		record =$("#brand_form").serialize();
		//console.log(record);
		$.post("../controllers/brand-action.php",record).success(function(res){
			$(".msg_brand").html(res);
		})
	})
	/////////////
	$(".btn-product").click(function(){
		//create an object of given form
		formobj=document.getElementById("product_form");
		//alert(formobj)
		//create an object of form data
		dataobj=new FormData(formobj);
		//alert(dataobj);
		//record=$("#product_form").serialize();
		$.ajax({
			type:"post",
			//u can write both get(for receiving data) or post(for giving data) 
			data:dataobj,
			url:"../controllers/product-action.php",
			contentType:false,//text/plain,enctype
			processData:false,
			success:function(res){
				$(".msg_product").html(res);
			},
			error:function(errmsg){
				console.log(errmsg)
			}
		});
	})
})