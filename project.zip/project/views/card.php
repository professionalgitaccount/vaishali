<?php 
	require_once "header.php";

?>
	<div class="container">
		<h2 class="text-center">CART</h2>
		<?php 
			print_r($_COOKIE);

		?>
	</div>
	


<?php 
	require_once "footer.php";

?>