<?php
require_once '../models/db_project.php';
//print_r($_POST);
$pid=$_POST['x'];
//echo $pid;
//print_r($_SESSION);
if(!isset($_SESSION['project_uid'])){
	echo "Please Do login";
}
else{
	$uid=$_SESSION['project_uid'];
	//echo $uid;
	//check count of pro ansd user
	$total=$obj->check_count_wishlist($pid,$uid);
	//pre($total);
	//exit;
	if($total[0]['cnt']>0){
		echo "Record exists in wishlist";
	}
	else{
		if($obj->wishlist_insert($pid,$uid)){
			echo "product Added in wishlist";
		}
	}

}
?>